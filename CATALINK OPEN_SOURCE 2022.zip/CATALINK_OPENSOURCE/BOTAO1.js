
window.onload= function () {
    // O Window.confirm serve para lembretes ou uma informação relevante para se usar ao utilizar os links abaixo
        window.confirm('AVISO PERSONALIZADO')
    //Cada Window.open refere-se a um link que sera aberto, segue a ordem de leitura
        window.open('https://github.com/olvriz');
        window.open('https://github.com/olvriz');
        window.open('https://github.com/olvriz');
        window.open('https://github.com/olvriz');
        window.open('https://github.com/olvriz');
    //Um resultado é exibido no console demonstrando a que a ação foi concluida
        console.log("Ação concluida com sucesso, Links abertos")
    }
    